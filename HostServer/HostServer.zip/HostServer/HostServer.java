/* 2012-05-20 Version 2.0

Thanks John Reagan for updates to original code by Clark Elliott.

Modified further on 2020-05-19

-----------------------------------------------------------------------

Play with this code. Add your own comments to it before you turn it in.

-----------------------------------------------------------------------

NOTE: This is NOT a suggested implementation for your agent platform,
but rather a running example of something that might serve some of
your needs, or provide a way to start thinking about what YOU would like to do.
You may freely use this code as long as you improve it and write your own comments.

-----------------------------------------------------------------------

TO EXECUTE: 

1. Start the HostServer in some shell. >> java HostServer

1. start a web browser and point it to http://localhost:4242. Enter some text and press
the submit button to simulate a state-maintained conversation.

2. start a second web browser, also pointed to http://localhost:4242 and do the same. Note
that the two agents do not interfere with one another.

3. To suggest to an agent that it migrate, enter the string "migrate"
in the text box and submit. The agent will migrate to a new port, but keep its old state.

During migration, stop at each step and view the source of the web page to see how the
server informs the client where it will be going in this stateless environment.

-----------------------------------------------------------------------------------

COMMENTS:

This is a simple framework for hosting agents that can migrate from
one server and port, to another server and port. For the example, the
server is always localhost, but the code would work the same on
different, and multiple, hosts.

State is implemented simply as an integer that is incremented. This represents the state
of some arbitrary conversation.

The example uses a standard, default, HostListener port of 4242.

-----------------------------------------------------------------------------------

DESIGN OVERVIEW

Here is the high-level design, more or less:

HOST SERVER
  Runs on some machine
  Port counter is just a global integer incrememented after each assignment
  Loop:
    Accept connection with a request for hosting
    Spawn an Agent Looper/Listener with the new, unique, port

AGENT LOOPER/LISTENER
  Make an initial state, or accept an existing state if this is a migration
  Get an available port from this host server
  Set the port number back to the client which now knows IP address and port of its
         new home.
  Loop:
    Accept connections from web client(s)
    Spawn an agent worker, and pass it the state and the parent socket blocked in this loop
  
AGENT WORKER
  If normal interaction, just update the state, and pretend to play the animal game
  (Migration should be decided autonomously by the agent, but we instigate it here with client)
  If Migration:
    Select a new host
    Send server a request for hosting, along with its state
    Get back a new port where it is now already living in its next incarnation
    Send HTML FORM to web client pointing to the new host/port.
    Wake up and kill the Parent AgentLooper/Listener by closing the socket
    Die

WEB CLIENT
  Just a standard web browser pointing to http://localhost:4242 to start.

  // I have written seperate print statements to print my name and date while executing from different webpages directing from the localhost
  to the server.

  -------------------------------------------------------------------------------*/

 import java.io.BufferedReader;// Buffer reading
 import java.io.IOException; //exceptions
 import java.io.InputStreamReader; // input reading from the data
 import java.io.PrintStream;
 import java.net.ServerSocket; // server socket accessing
 import java.net.Socket;
/**
 * HostServer Notes: This went pretty smoothly for me, although I did have to edit the HTML functions
 * to get an accurate content length so things would be compatible with browsers other than IE. I also modified
 * things to eliminate inaccurate state numbers based on fav.ico requests. If the string person wasnt found,
 * the requests was ignored
 */

 
 /* 
Notes on AgentWorker class:
the main functionality of this class is to read what was inputed in the text box and do something with it.
For example if it was migrate it printed on the webpage: 
    We are migrating to host 3006
    View the source of this page to see how the client is informed of the new location.
Whease as if anything else was endtered it printed on the webpage: 
    We are having a conversation with state 12
And if there was an error, or incorrect input it printed on the webpage: 
    You have not entered a valid request!

This class also made a few other calls to other classes. i.e. agentHolder and AgentListener. 
This class is also made as a call in the AgentListener class
*/

  class AgentWorker extends Thread {//start of the AgentWorker class 

    Socket sock; //creating a new socket to initalize
    agentHolder parentAgentHolder;
    int localPort;//new localPort is been initialized.

    AgentWorker(Socket s, int prt, agentHolder ah) { //AgentWorker, takes a Socket, int and an agentHolder
        sock = s; //assigns the Socket s
        localPort = prt; // assigns the localport to the port address
        parentAgentHolder = ah;// assigns the agentHolder ah to parentHolder
    }

    public void run() {

        PrintStream out = null; //PrintStream output is assigned to null
        BufferedReader in = null;//BufferedReader in is assigned to null
        String NewHost = "localhost"; //NewHost is assigned to localhost
        int NewHostMainPort = 4242;//localhost will run port that is assigned to 4242
        String buf = "";  //buf assigned waiting for the value
        int newPort; //newPort initialized.
        Socket clientSock;
        BufferedReader fromHostServer; //BufferedReader fromHostServer is been initialized.
        PrintStream toHostServer; //PrintStream toHostServer is been initialized.

        try {
            out = new PrintStream(sock.getOutputStream());
            in = new BufferedReader(new InputStreamReader(sock.getInputStream())); //new BufferedReader and new InputStreamReader that gets the Input Stream from sock and assigns it to in.

            String inLine = in.readLine();
            StringBuilder htmlString = new StringBuilder(); //new StringBuilder assigned to a new StringBuilder variable called htmlString. A StringBuilder is an editable string. or a seqance or chars that can be edited.

            System.out.println();
            System.out.println("Request line: " + inLine); // prints Request line: + what is stored in inLine.

            if (inLine.indexOf("migrate") > -1) {//if statement to see the user entered migrate
                clientSock = new Socket(NewHost, NewHostMainPort); //new Socket that takes in the string NewHost that is assigned to localhost and an int NewHostMainPort that is assigned to 4242
                fromHostServer = new BufferedReader(new InputStreamReader(clientSock.getInputStream()));
                toHostServer = new PrintStream(clientSock.getOutputStream()); //new PrintStream that takes in the Ouput Stream of clientSock. Then assigns it to toHostServer
                toHostServer.println("Please host me. Send my port! [State=" + parentAgentHolder.agentState + "]");// prints Please host me. Send my port!

                toHostServer.flush(); //flushes PrintStream toHostServer
                for (; ; ) {
                    buf = fromHostServer.readLine();
                    if (buf.indexOf("[Port=") > -1) {//checks to see if buf the index of [Port= is greater than or = to 0
                        break;
                    }
                }

                String tempbuf = buf.substring(buf.indexOf("[Port=") + 6, buf.indexOf("]", buf.indexOf("[Port="))); //new string called tempbuf

                newPort = Integer.parseInt(tempbuf); //takes the string tempbuf and pases it into an int. Sets the int = to newPort
                System.out.println("newPort is: " + newPort); //prints newPort is: + the newPort number.

                htmlString.append(AgentListener.sendHTMLheader(newPort, NewHost, inLine));//apends to the StringBuilder htmlString.

                htmlString.append("<h3>We are migrating to host " + newPort + "</h3> \n");//apends to the StringBuilder htmlString.

                htmlString.append("<h3>View the source of this page to see how the client is informed of the new location.</h3> \n"); //apends to the StringBuilder htmlString.

                htmlString.append(AgentListener.sendHTMLsubmit());//apends to the StringBuilder htmlString.

                System.out.println("Killing parent listening loop.");//prints Killing parent listening loop.
                ServerSocket ss = parentAgentHolder.sock; // ServerSocket called ss. that gets parentAgentHolder.sock
                ss.close();
            } else if (inLine.indexOf("person") > -1) {//checks to see if index of person is greater than or = to 0.
                parentAgentHolder.agentState++; //adds to the agentState in the agentHolder parentAgentHolder.
                htmlString.append(AgentListener.sendHTMLheader(localPort, NewHost, inLine));//apends to the StringBuilder htmlString.
                //sends the int newPort, string NewHost, and the sting inLine to AgentListener.sendHTMLheader
                htmlString.append("<h3>We are having a conversation with state   " + parentAgentHolder.agentState + "</h3>\n");//apends to the StringBuilder htmlString.
                htmlString.append(AgentListener.sendHTMLsubmit());//apends to the StringBuilder htmlString.
            } else {
                htmlString.append(AgentListener.sendHTMLheader(localPort, NewHost, inLine));//apends to the StringBuilder htmlString.
                htmlString.append("You have not entered a valid request!\n");//apends to the StringBuilder htmlString.
                htmlString.append(AgentListener.sendHTMLsubmit());//apends to the StringBuilder htmlString.
            }
            AgentListener.sendHTMLtoStream(htmlString.toString(), out);//send htmlString as a string and out to sendHTMLtoStream
            sock.close();//closes Socket sock
        } catch (IOException ioe) { //Catch if try fails. IOException
            System.out.println(ioe);//prints ioe if try fails
        }
    }
/* 
Notes on agentHolder class:
This is a simple class that allows other classes to call agentHolder and takes in a ServerSocket. 
It also has a int agentState initialized. that other classes call to.
This class is used in the AgentWorker class and the AgentListener class. 
*/

    class agentHolder { //start of class agentHolder
        ServerSocket sock;// new ServerSocket called sock initialized.
        int agentState;//new int called agentState initialized.

        agentHolder(ServerSocket s) {//start of agentHolder call. Takes in a ServerSocket.
            sock = s;
        }// end of agentHolder call
    }//clases class agentHolder
  
/* 
Notes on AgentListener class:
the main purpus of this class is to make the html form 
this class is called by AgentWorker and HostServer
it calles AgentWorker in its code.
*/

    class AgentListener extends Thread { //new class AgentListener that extends Thread
        Socket sock;//new socket called sock initialized.
        int localPort; //new int called localPort initialized.

        AgentListener(Socket As, int prt) { //start of AgentListener
            sock = As;//assigns the Socket sock
            localPort = prt; //assigns the int localPort
        }

        int agentState = 0;//new int called agentState set to 0.

        public void run() {
            BufferedReader in = null; //BufferedReader called in and set to null
            PrintStream out = null; // PrintStream called out and set to null
            String NewHost = "localhost"; //new String called NewHost and set to localhost
            System.out.println("In AgentListener Thread");//prints In AgentListener Thread
            try {
                String buf;
                out = new PrintStream(sock.getOutputStream()); //PrintStream that gets the Output Stream
                in = new BufferedReader(new InputStreamReader(sock.getInputStream())); //new BufferedReader and new InputStreamReader
                buf = in.readLine(); //reads the lines in in and assigns them to buf
                if (buf != null && buf.indexOf("[State=") > -1) {//if buff is not null and its index of [State= is greaterthan or = to 0.
                    String tempbuf = buf.substring(buf.indexOf("[State=") + 7, buf.indexOf("]", buf.indexOf("[State="))); //new string tempbuf

                    agentState = Integer.parseInt(tempbuf);
                    System.out.println("agentState is: " + agentState);

                }

                System.out.println(buf); //prints buf


                StringBuilder htmlResponse = new StringBuilder(); //new StringBuilder called htmlResponse
                htmlResponse.append(sendHTMLheader(localPort, NewHost, buf)); //apends to the StringBuilder htmlResponse.
                //sends the int newPort, string NewHost, and the sting inLine to sendHTMLheader
                htmlResponse.append("Now in Agent Looper starting Agent Listening Loop\n<br />\n"); //apends to the StringBuilder htmlResponse.
                //print statement to HTML webpage only when page is first loaded on local host
                htmlResponse.append("[Port=" + localPort + "]<br/>\n");//apends to the StringBuilder htmlResponse.

                htmlResponse.append(sendHTMLsubmit());//apends to the StringBuilder htmlResponse.
                sendHTMLtoStream(htmlResponse.toString(), out); //send htmlResponse as a string and out to sendHTMLtoStream

                ServerSocket servsock = new ServerSocket(localPort, 2); //new ServerSocket called servsock. Takes in localPort and 2.
                agentHolder agenthold = new agentHolder(servsock); //new agentHolder called agenthold. Takes in servsock
                agenthold.agentState = agentState;

                while (true) {//while true do the following code
                    sock = servsock.accept();//accepts servsock and assigns it to sock
                    System.out.println("Got a connection to agent at port " + localPort);//print Got a connection to agent at port + localPort
                    //example : Got a connection to agent at port 3002
                    new AgentWorker(sock, localPort, agenthold).start();//new AgentWorker starts. takes in sock, localPort, agenthold
                }

            }
            catch (IOException ioe) {//catch when the try fails
                System.out.println("Either connection failed, or just killed listener loop for agent at port " + localPort);//prints this to terminal
                System.out.println(ioe);//prints ioe

            }
        }

        static String sendHTMLheader(int localPort, String NewHost, String inLine) {//start of sendHTMLheader. Takes in an int localPort a String NewHost and a String inLine.
            StringBuilder htmlString = new StringBuilder();// //new StringBuilder called htmlString
            htmlString.append("<html><head> </head><body>\n"); //apends to the StringBuilder htmlString.
            htmlString.append("<h2>This is for submission to PORT " + localPort + " on " + NewHost + "</h2>\n");//apends to the StringBuilder htmlString.
            htmlString.append("<h3>You sent: " + inLine + "</h3>");//apends to the StringBuilder htmlString.
            htmlString.append("\n<form method=\"GET\" action=\"http://" + NewHost + ":" + localPort + "\">\n");//apends to the StringBuilder htmlString.
            //new line and the form.
            htmlString.append("Enter text or <i>migrate</i>:"); //apends to the StringBuilder htmlString.
            // text before the form Enter text or migrate with migrate being italzized
            htmlString.append("\n<input type=\"text\" name=\"person\" size=\"20\" value=\"YourTextInput\" /> <p>\n");//apends to the StringBuilder htmlString.
            //makes the value in the box YourTextInput
            return htmlString.toString(); //retuns the htmlString as a string
        }

        static String sendHTMLsubmit() {//start of sendHTMLsubmit
            return "<input type=\"submit\" value=\"Submit\"" + "</p>\n</form></body></html>\n";//retruns this
        }

        static void sendHTMLtoStream(String html, PrintStream out) {//start of sendHTMLtoStream

            out.println("HTTP/1.1 200 OK");//prints to terinal
            out.println("Content-Length: " + html.length());
            out.println("Content-Type: text/html");//prints to terinal
            out.println("");//prints to terinal
            out.println(html);
        }

    }

    /*
   Notes on HostServer class:
   this is the main class of the program.
   The purpose of this class is to print some basic statements and start the AgentListener
   */
    public class HostServer {//start of HostServer class. The main class for the program.
        public static int NextPort = 3000;//new public int called NextPort and set to NextPort

        public void main(String[] a) throws IOException {//start of main thows IOException
            int q_len = 6;//new int called q_len assigned to 6
            int port = 4242;// new in called port and assigned to 4242
            Socket sock;//new socket called sock
            ServerSocket servsock = new ServerSocket(port, q_len); //new ServerSocket called servsock that takes in port and q_len. ie, 6 and 4242
            System.out.println("Elliott/Reagan DIA Master receiver started at port 4242.");//prints this to terminal
            System.out.println("With small edits and comments from Nihar Muniraju. 5/03/2023");//added this text to show that this is my comments and small changes
            System.out.println("Connect from 1 to 3 browsers using \"http:\\\\localhost:4242\"\n");//prints this to terminal
            while (true) {//while true do the following code
                NextPort = NextPort + 1;//add 1 to each new port. 3001, 3002, 3003 .... and so on
                sock = servsock.accept();// accept servsock and assign to sock
                System.out.println("Starting AgentListener at port " + NextPort);//print Starting AgentListener at port + NextPort
                //example : Starting AgentListener at port 3002
                new AgentListener(sock, NextPort).start(); // starts AgentListener with sock and NextPort
            }
        }
    }
}

// -------output for the code----------
  /**
          Elliott/Reagan DIA Master receiver started at port 4242.
          With small edits and comments from Nihar Muniraju. 5/03/2023
          Connect from 1 to 3 browsers using "http:\\localhost:4242"

          Starting AgentListener at port 3001
          Starting AgentListener at port 3002
          In AgentListener Thread
          In AgentListener Thread
          GET / HTTP/1.1
          Starting AgentListener at port 3003
          In AgentListener Thread
          GET / HTTP/1.1
          GET /favicon.ico HTTP/1.1
          Got a connection to agent at port 3001
          Got a connection to agent at port 3001

          Request line: GET /?person=Nihar HTTP/1.1
          Got a connection to agent at port 3001

          Request line: GET /?person=Nihar HTTP/1.1

          Request line: GET /favicon.ico HTTP/1.1
          Got a connection to agent at port 3001
          Got a connection to agent at port 3001

          Request line: GET /?person=migrate HTTP/1.1
          Starting AgentListener at port 3004
          In AgentListener Thread
          agentState is: 2
          Please host me. Send my port! [State=2]
          newPort is: 3004
          Killing parent listening loop.
          Either connection failed, or just killed listener loop for agent at port 3001
          java.net.SocketException: Socket closed

          Request line: GET /favicon.ico HTTP/1.1
          Starting AgentListener at port 3005
          Starting AgentListener at port 3006
          In AgentListener Thread
          In AgentListener Thread
          GET / HTTP/1.1
          Starting AgentListener at port 3007
          In AgentListener Thread
          GET / HTTP/1.1
          GET /favicon.ico HTTP/1.1
          Got a connection to agent at port 3006
          Got a connection to agent at port 3006

          Request line: GET /?person=nikhil HTTP/1.1
          Got a connection to agent at port 3006

          Request line: GET /?person=nikhil HTTP/1.1

          Request line: GET /favicon.ico HTTP/1.1
          Starting AgentListener at port 3008
          Starting AgentListener at port 3009
          In AgentListener Thread
          In AgentListener Thread
          GET / HTTP/1.1
          Starting AgentListener at port 3010
          In AgentListener Thread
          GET / HTTP/1.1
          GET /favicon.ico HTTP/1.1
          Got a connection to agent at port 3009
          Got a connection to agent at port 3009

          Request line: GET /?person=Trishika HTTP/1.1
          Got a connection to agent at port 3009

          Request line: GET /?person=Trishika HTTP/1.1

          Request line: GET /favicon.ico HTTP/1.1
*/