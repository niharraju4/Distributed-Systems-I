
/*

   Nihar MUNIRAJU/ Date: 1/22/2023
         Java version used : build JAVA SE 19.0.2
       command-line compilation / instructions:
        > javac JokeClientAdmin*.java
        4.In shell windows:
        > java JokeClientAdmin
        or
        > java JokeClientAdmin localhost
        -> We Will run the Joke ClientAdmin when the jokeClient is already in the running state.
        -> it states the joke client its running so if the user needs to switch between the jokes and the server it helps the joke client.
        -> once the server is noted that the jokeClientAdmin is turned on it recieves port connection and it ensures the mode is changed.
        -> the mode is been printed changed from either joke to proverb or proverb to joke and then the jokeclient is changed accourdingly.
        JokeServer.java
        JokeClient.java
       JokeClientAdmin.java


*/





import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.UUID;
public class JokeClientAdmin {

    private static final int ClientAdminPrimaryPort = 5050;//JokeServer primary connections being used as deafault port1

    private static final int ClientAdminSecondaryPort = 5051;//JokeServer Secondary connections being used as default port2

    static boolean isPrimary = true;


    public static void main(String args[]) {
        String primaryPortAddress = "localhost";//the Primary adress connects to the localhost of the system being used.
        String secondaryPortAddress = " ";

        System.out.println(" Started Nihar Muniraju Joke Admin Client.\n");

        if (args.length > 0) {//using the first primary adress
            primaryPortAddress = args[0];
        }

        if (args.length > 1) {
            primaryPortAddress = args[1];
        }
// Chceking if the ClientAdmin state of the ports can be connected to the server
        System.out.println("AdminfirstServer: " + primaryPortAddress + ", port " + ClientAdminPrimaryPort);
        if (!secondaryPortAddress.isEmpty()) {
            System.out.println("AdminsecondServer: " + secondaryPortAddress + ", port " + ClientAdminSecondaryPort);
        }
//has the data to send to the servers as input
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String input;

        try {

            System.out.println("Give a command, Click on Enter for a Joke or Proverb, or press S to toggle between the servers or type \"quit\" or \"turnoff\"to turnoff and exit.");
            System.out.flush();

            do {
                input = in.readLine();

                if (input.equalsIgnoreCase("s")) {//it lets to toggle between the joke and client by sending datat to the server
                    if (secondaryPortAddress.isEmpty()) {
                        System.out.println("None of the Secondary server are used.");
                    } else {
                        if (isPrimary) {
                            System.out.println("Contacting with: " + secondaryPortAddress + ", port " + ClientAdminSecondaryPort);
                        } else {
                            System.out.println("Contacting with: " + primaryPortAddress + ", port " + ClientAdminPrimaryPort);
                        }
                        isPrimary = !isPrimary;
                    }// it checks if the user wants to stop the process by quiting or turning off the clientAdmin
                } else if (input.isEmpty() || input.equalsIgnoreCase("turnoff")) {

                    if (isPrimary) {
                        getConnect(input, primaryPortAddress, ClientAdminPrimaryPort);
                    } else {
                        getConnect(input, secondaryPortAddress, ClientAdminSecondaryPort);
                    }
                }
            }//always keeps checking about the quit
            while (input.indexOf("quit") < 0);

            System.out.println("Accepted the given quit command and will exit.");
        } catch (IOException x) {
            System.out.println(x);
        }
    }
    static void getConnect(String input, String serversName, int port) {
        Socket sock;
        BufferedReader fromServer;
        PrintStream toServer;
        String textFromServer;

        try {///a new socket will be turned on as a swtich to connect and transfer data
            sock = new Socket(serversName, port);
            fromServer = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            toServer = new PrintStream(sock.getOutputStream());

            toServer.println(input);
            toServer.flush();

            textFromServer = fromServer.readLine();

                if (textFromServer != null){
                    System.out.println(textFromServer);  //print from the server
            }
            sock.close();

        } catch (IOException x) {
            x.printStackTrace();//if not able to toggle and communicate
        }

    }
}
