/*

   Nihar MUNIRAJU/ Date: 1/22/2023
         Java version used : build JAVA SE 19.0.2
       command-line compilation / instructions:
        > javac JokeClient*.java
        4.In shell windows:
        > java JokeClient
        or
        > java JokeClient localhost
            -> We first have to run the jokeServer to ensure the ports are open for the clients to connect.
        -> We Will run the Joke Client on the localhost and it will connect with server1 as it connects it shows the port address 4545 or others that is connected.
        ->The client then asks for the name to use for the client to run the server.
        -> Once the name is entered the local host is connected to the server.
        -> it will ask us to either enter to run a joke or a proverb in random way and then once its running it'll update it on the server simlatenously.
        -> Once the entire 4 jokes or proverb are done it says that it it is completed and again it will take jokes and proverbs in random order.
        -> You are free to press "s" to toggle between all the servers if your secondary server is running already.
        ->If the mode has to be changed then you request the JokeClientAdmin to press enter to change the joke to proverb or a proverb to a joke.
        -> Once it states the server the joke made is changed to server mode then the client automatically changes and outputs the result in the server.

        a. JokeServer.java
        b. JokeClient.java
        c. JokeClientAdmin.java


*/


import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.UUID;
public class JokeClient {
//JokeServer primary connections being used as deafault port1
    private static final int Def_primaryPort_server = 4545;
    //JokeServer Secondary connections being used as default port2
    private static final int Def_SecondaryPort_server = 4546;


    public static void main(String args[])
    {
        String primaryPortAddress = "localhost";//the Primary adress connects to the localhost of the system being used.
        String secondaryPortAddress = new String("");
        Boolean isPrimary = true;
        String userIdName = new String("");//username being used for idetifing.
        UUID id = UUID.randomUUID();// randomly taking unique different connections for the servers.
        String userId = id.toString();// to convert the id level to a string level so that we can access it.

        if (args.length == 1)
        {
            secondaryPortAddress = args[0];
        }//states the client about theJokeCLient being started
        System.out.println(" Started Nihar Muniraju JokeClient.\n");
//its definitely checking the ports here with their given addresses and printing them
        System.out.println("firstServer: " + primaryPortAddress + ", port " + Def_primaryPort_server);
        if (!secondaryPortAddress.isEmpty()) {
            System.out.println("secondServer: " + secondaryPortAddress + ", port " + Def_SecondaryPort_server);
        }
//to take the given input and take it as a INPUT
        Scanner in = new Scanner(System.in);
        String input;

        do {
// It records the name for the continously printing name in the client
            System.out.println("Input your User Name: ");
            System.out.flush();//flushing out data
            userIdName = in.nextLine();//moving the data to the next line
//MadeSure the length should be more than 4 to start the server getting to the client.
            if (userIdName.isEmpty() || userIdName.length() < 4) {
                System.out.println("Please Fill your User Name with Minimum user name length should be atleast four characters");
            }
        }
        while (userIdName.isEmpty()  || userIdName.length() < 4);
//checks until its empty.
        System.out.println("Give a command, Click on Enter for a Joke or Proverb, or press S to toggle between the servers or type \"quit\" to exit.");
        System.out.flush();

        do {
            input = in.nextLine();//cheking for the user given input to take it in.

            if (input.equalsIgnoreCase("quit")) {//ther ports are connected between primary and secondary from client to the server
                //and the data can be deleted by pressing quit and the process of the threading will be stopped.
                getConnectionToServer(userIdName, userId, true, primaryPortAddress, Def_primaryPort_server);
                if (!secondaryPortAddress.isEmpty()) {
                    getConnectionToServer(userIdName, userId, true, secondaryPortAddress, Def_SecondaryPort_server);
                }
//It also checks if the user wants to use a toggle switch between joke and client and also it will update the server about it with its ports
            } else if (input.equalsIgnoreCase("s")) {
                if (secondaryPortAddress == null || secondaryPortAddress.isEmpty()) {
                    System.out.println("Secondary server is not being used");
                } else {
                    if (isPrimary) {//connecting both primary and secondary ports while the toggle is started.
                        System.out.println("Contacting with: " + secondaryPortAddress + ", port " + Def_SecondaryPort_server);
                    } else {
                        System.out.println("Contacting with: " + primaryPortAddress + ", port " + Def_primaryPort_server);
                    }
                    isPrimary = !isPrimary;
                }
            } else if (input.isEmpty()) //Worstcase Scenario if we recieve an empty input to the server
            {

                if (isPrimary) {
                    getConnectionToServer(userIdName, userId, false, primaryPortAddress, Def_primaryPort_server);
                } else {
                    getConnectionToServer(userIdName, userId, false, secondaryPortAddress, Def_SecondaryPort_server);
                }
            }
        }//always keeps noted and then it quits from the user.
        while (input.indexOf("quit") < 0);

        System.out.println("Accepted given quit command and will exit.");
    }

    static void getConnectionToServer(String userIdName, String userId, Boolean quit, String serversName, int port)
    {
        Socket sock;
        BufferedReader fromServer;
        PrintStream toServer;
        String textFromServer;

        try
        {//a new socket will be turned on as a swtich to connect and transfer data
            sock = new Socket(serversName, port);
            fromServer = new BufferedReader(new InputStreamReader(sock.getInputStream()));//to read the data
            toServer = new PrintStream(sock.getOutputStream());

            toServer.println(userIdName); //UserName
            toServer.flush();

            toServer.println(userId);
            toServer.flush();

            toServer.println(quit.toString());
            toServer.flush();

            for (int i = 0; i <= 2; i++) {
                textFromServer = fromServer.readLine();
                if (textFromServer != null) System.out.println(textFromServer); //print from the server
            }
            sock.close();

        } catch (IOException x) {
            System.out.println("Socket error.");//if not able to toggle and communicate
            x.printStackTrace();
        }

    }
}
