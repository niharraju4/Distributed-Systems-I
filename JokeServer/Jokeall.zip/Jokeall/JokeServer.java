/*

   Nihar MUNIRAJU/ Date: 1/22/2023
         Java version used : build JAVA SE 19.0.2
       command-line compilation / instructions:
        > javac JokeServer*.java
        4.In shell windows:
        > java JokeServer
        or
        > java JokeServer Secondary[to run the secondary server simultaneously]
        -> We first have to run the jokeServer to ensure the ports are open for the clients to connect.
        -> We Will run the Joke Client on the localhost and it will connect with server1 as it connects it shows the port address 4545 or others that is connected.
        ->The client then asks for the name to use for the client to run the server.
        -> Once the name is entered the local host is connected to the server.
        -> it will ask us to either enter to run a joke or a proverb in random way and then once its running it'll update it on the server simlatenously.
        -> Once the entire 4 jokes or proverb are done it says that it it is completed and again it will take jokes and proverbs in random order.
        -> You are free to press "s" to toggle between all the servers if your secondary server is running already.
        ->If the mode has to be changed then you request the JokeClientAdmin to press enter to change the joke to proverb or a proverb to a joke.
        -> Once it states the server the joke made is changed to server mode then the client automatically changes and outputs the result in the server.
        -> The second server can be turned on using JokeServer Secondary to run the second server and will be waiting for ports to run.
        ->Once the Server is turned on the second JokeClient can be opned and the name would ebn entered to do multithreading and once you press enter it prints.
        -> But it only updates the FIRSTServer as it is still not be accessed to toggle by the secondary server.
        ->Once we press "s"it toggles and connects it port to the Seconary server and it idetifies its port.
        ->So once you toggle you can go back by pressing ENTER again and switching the servers between first and second.
        And these are the commands you have to run to compile and do multithreading in JOKEsERVER.

      JokeServer.java
     JokeClient.java
       JokeClientAdmin.java
       JokeClient2.java
       JokeServer Seconary.java


*/




import java.io.*;
import java.net.*;
import java.util.*;

class JokeComplete extends Thread {
    Socket sock;
    JokeComplete (Socket sock) { this.sock = sock; }//using the socket fo the connection for communication

    public void run(){

        PrintStream out = null;
        BufferedReader in = null;
        UtilizationData tempData = null;

        try{
           //Sending all the in inputs and cheking if the buffered data is sending i tto the required clientsd
            in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            out = new PrintStream(sock.getOutputStream());

            try {
                String userIdName; //using the userName for the client and Server
                String userIds;
                Boolean quit; //keeps checking if the quit was been called.
                userIdName = in.readLine(); //Reading the name from the given thread in server
                userIds =  in.readLine(); //Reading the  userId from given thread in server
                quit = Boolean.valueOf(in.readLine()); //quit

                if(!quit)
                { //if we never quit then checking the hashmap
                    System.out.println(JokeServer.alternativeTarget +"Checking the data of the user: " + userIdName + " " + userIds);

                    tempData = JokeServer.usersMap.get(userIdName + userIds);//check weather to randomize joke or proverb

                    if(tempData == null)
                    {//keeps checking for alternate targets fom different clients
                        System.out.println(JokeServer.alternativeTarget +"When data not found, create a new set of data.");
                        tempData = new UtilizationData(userIdName);
                        JokeServer.usersMap.put(userIdName + userIds, tempData);
                    }
                    else
                    {//prints when the client connects to the port to transfer data
                        System.out.println(JokeServer.alternativeTarget +"Found the user data");
                    }

                    //always checks weathers its running in joke mode or proverb and tries to print the present data
                    if(JokeServer.mode.equals("Joke"))
                    {
                        out.println(JokeServer.alternativeTarget + tempData.getJoke());
                        System.out.println(JokeServer.alternativeTarget + "Sent " + JokeServer.mode +" " + (tempData.getJokeIndex() + 1) + "/4 to user: " + userIdName + " " + userIds);
                        tempData.increaseJokeIndex();
                        if(tempData.getJokeIndex() == 0)
                        {
                            //log and send back message stating that the current cycle has completed
                            System.out.println(JokeServer.alternativeTarget + "One Cycle of JOKE is finished");
                            out.println(JokeServer.alternativeTarget + "One Cycle of JOKE is finished");
                        }
                    }
                    else
                    {
                        out.println(JokeServer.alternativeTarget + tempData.getProverb());
                        System.out.println(JokeServer.alternativeTarget + "Sent " + JokeServer.mode +" " + (tempData.getProverbIndex() + 1) + "/4 to user: " + userIdName + " " + userIds);
                        tempData.increaseProverbIndex();
                        if(tempData.getProverbIndex() == 0)
                        {

                            System.out.println(JokeServer.alternativeTarget + "One Cycle of PROVERB is finished");
                            out.println(JokeServer.alternativeTarget + "One Cycle of PROVERB is finished");
                        }
                    }

                }
                else
                {


                    if(userIds.isEmpty()) {
                        System.out.println(JokeServer.alternativeTarget + "turning down the server!");
                        out.println(JokeServer.alternativeTarget + "Server is turning off!");
                        JokeServer.usersMap.clear(); //it makes sure there is a void in a hashmap


                    }
                    else
                    {

                        System.out.println(JokeServer.alternativeTarget + "User stating Quit : " + userIdName + " " + userIds + " Deleting the user data");
                        if(JokeServer.usersMap.containsKey(userIdName + userIds)) {
                            JokeServer.usersMap.remove(userIdName + userIds);
                        }
                    }
                }

            }catch (IOException a){

                System.out.println(JokeServer.alternativeTarget + "Error server not able to read");
                a.printStackTrace();
            }

            sock.close();
        } catch (IOException x){
            System.out.println(x);
        }
    }

}

class UtilizationData{


    private List<String> jokesArray = new LinkedList<String>();
    private List<String> proverbArray = new LinkedList<String>();
    private int jokeIndex = 0;
    private int proverbIndex = 0;

    public int getJokeIndex() {
        return jokeIndex;
    }


    public int getProverbIndex() {
        return proverbIndex;
    }

    public String getJoke() {
        return jokesArray.get(jokeIndex);
    }


    public String getProverb() {
        return proverbArray.get(proverbIndex);
    }


    public void increaseJokeIndex() {
        jokeIndex++;
        if(jokeIndex > 3) {
            jokeIndex = 0;
            Collections.shuffle(jokesArray);
        }
    }


    public void increaseProverbIndex() {
        proverbIndex++;
        if(proverbIndex > 3) {
            proverbIndex = 0;
            Collections.shuffle(proverbArray);
        }
    }


    UtilizationData(String username){
        jokesArray.add("JA " + username + ": What did the triangle say to the circle? You are pointless.");
        jokesArray.add("JB " + username + ": What do elves learn in school? The elfabet.");
        jokesArray.add("JC " + username + ": Time flies like an arrow? Fruit flies like a bannana.");
        jokesArray.add("JD " + username + ": Why do cows wear bells? Because thier horns dont work.");
        Collections.shuffle(jokesArray);
        proverbArray.add("PA " + username + ": A rolling stone gathers no mass.");
        proverbArray.add("PB " + username + ": The early bird catches the worm.");
        proverbArray.add("PC " + username + ": A snitch in time saves nine.");
        proverbArray.add("PD " + username + ": The squeaky wheel gets the grease.");
        Collections.shuffle(proverbArray);
    }
}

public class JokeServer{

    public static final Integer Def_primaryPort_server = 4545;
    public static final Integer Def_SecondaryPort_server = 4546;
    static String mode = "Joke";
    static boolean isPrimary = true;
    static Map<String, UtilizationData> usersMap = new LinkedHashMap<String, UtilizationData>();
    static Boolean isRunning = true;
    static String alternativeTarget = "SecondaryServer";

    public static void main(String ar[]) throws IOException{

        String secServ = "Secondary ";
        Integer port = Integer.parseInt("0");
        int q_len = 6;


        if(ar.length==1 && ar[0].equalsIgnoreCase("secondary")){
            port = Def_SecondaryPort_server;
            isPrimary = false;
        }else{
            port = Def_primaryPort_server;
            alternativeTarget = "";
            secServ = "";
        }

        Socket sock;
        ServerSocket sSock = new ServerSocket(port, q_len);

        Supervisor adminRun = new Supervisor(); //We instantiate the Admin class
        Thread ad = new Thread(adminRun); //We create a new thread for the Amin Server
        ad.start();

        System.out.println(alternativeTarget +"Nihar Muniraju "+ secServ + "Joke Server starting up, listening at port " + port + ".\n");

        while(isRunning){
            sock = sSock.accept();
            new JokeComplete(sock).start();
        }
        sSock.close();
    }
}

class Supervisor implements Runnable {


    public static final int ClientAdminPrimaryPort = 5050;
    public static final int ClientAdminSecondaryPort = 5051;

    public void run() {

        Socket sock;
        int q_len= 6;
        int adminPort;

        if(JokeServer.isPrimary) {
            adminPort = ClientAdminPrimaryPort;
        }else {
            adminPort = ClientAdminSecondaryPort;
        }

        try {

            System.out.println(JokeServer.alternativeTarget + "Nihar Muniraju Admin Server starting , listening at port " + adminPort + ".\n");
            ServerSocket sSock = new ServerSocket(adminPort, q_len);


            while(JokeServer.isRunning) {
                sock = sSock.accept();
                new ClientAdminWorker(sock).start();
            }

            sSock.close();

        }catch(IOException io){
            System.out.println(io);
        }
    }

}

class ClientAdminWorker extends Thread{


    Socket sock;

    ClientAdminWorker(Socket s){
        sock = s;
    }

    public void run(){

        PrintStream out = null;
        BufferedReader in = null;
        String input = "";

        try{

            in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            out = new PrintStream(sock.getOutputStream());

            input = in.readLine(); //read the command


            if(input.equalsIgnoreCase("shutdown")) {

                JokeServer.isRunning = false; //set running flag to false
                System.out.println(JokeServer.alternativeTarget + "TURNOFF is been activacted");
                out.println(JokeServer.alternativeTarget + "Server has shutdown from JokeClientAdmin"); //notify the JokeClientAdmin that the server is shutting down
                int tempPort  = JokeServer.Def_primaryPort_server;
                if(!JokeServer.isPrimary) {
                    tempPort = JokeServer.Def_SecondaryPort_server;
                }
                Socket tempSock = new Socket("localhost", tempPort);
                PrintStream outTemp = new PrintStream(tempSock.getOutputStream());
                outTemp.println();
                outTemp.flush();
                outTemp.println();
                outTemp.flush();
                outTemp.println("true");
                outTemp.flush();
                tempSock.close();

                tempPort = Supervisor.ClientAdminPrimaryPort;
                if(!JokeServer.isPrimary) {
                    tempPort = Supervisor.ClientAdminSecondaryPort;
                }
                tempSock = new Socket("localhost", tempPort);
                outTemp = new PrintStream(tempSock.getOutputStream());
                outTemp.println();
                outTemp.flush();
                tempSock.close();

            }else if(input.isEmpty()) {


                if(JokeServer.mode.equals("Joke")) {
                    JokeServer.mode = "Proverb";
                }else {
                    JokeServer.mode = "Joke";
                }

                String temp = JokeServer.alternativeTarget + "JokeServer switched to " + JokeServer.mode + " mode";
                System.out.println(temp);
                out.println(temp);
                out.flush();
            }

        } catch(IOException io) {
            System.out.println(io);
        }
    }


}
