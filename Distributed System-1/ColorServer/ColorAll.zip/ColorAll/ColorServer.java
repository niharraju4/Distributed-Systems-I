/*Name: Nihar Muniraju
Date: 01-12-2023
Java Version: 19.0.1

        Thanks:

        https://www.comrevo.com/2019/07/Sending-objects-over-sockets-Java-example-How-to-send-serialized-object-over-network-in-Java.html (Code dated 2019-07-09, by Ramesh)
        https://rollbar.com/blog/java-socketexception/#
        Also: Hughes, Shoffner and Winslow for Inet code.
*/

import java.io.*;
import java.net.*;

class ColorData implements Serializable {

    String userName;//for userName
    String colorSent;//for the color being sent
    String colorSentBack;// for the color being sentBack
    String messageToClient;// for messagetTOClient
    int colorCount;// for colorCount
}

class ColorWorker extends Thread { // to run all the threads at once
    Socket sock;
    ColorWorker (Socket s) {sock = s;} //connecting the sockets

    public void run(){
        try {

            InputStream InStream = sock.getInputStream();// to take input datastream
            ObjectInputStream ObjectIS = new ObjectInputStream(InStream);// constructor used for the incoming connection

            ColorData InObject = (ColorData) ObjectIS.readObject();

            OutputStream outStream = sock.getOutputStream();
            ObjectOutputStream objectOS = new ObjectOutputStream(outStream);
//checking all the print statements
            System.out.println("\nFROM THE CLIENT:\n");
            System.out.println("Username: " + InObject.userName);
            System.out.println("Color sent from the client: " + InObject.colorSent);
            System.out.println("Connections count (State!): " + (InObject.colorCount + 1));

            InObject.colorSentBack = getRandomColor();//choosing from the random color given
            InObject.colorCount++;
            InObject.messageToClient = String.format("Thanks %s for sending the color %s", InObject.userName, InObject.colorSent);
// writing the data to the object and returning
            objectOS.writeObject(InObject);

            System.out.println("Closing the client socket connections...");
            sock.close();
        }catch(ClassNotFoundException CNF){
            CNF.printStackTrace();
 } catch (IOException x){
System.out.println("Server error.");
x.printStackTrace();
}
}
    String getRandomColor(){
    String[] colorArray = new String[]
 {
 "Red", "Blue", "Green", " Yellow", "Magenta", "Silver", "Aqua", "Gray", "Peach", "Orange"
    };// all the colors to be used
int randomArrayIndex = (int) (Math.random() * colorArray.length);
return (colorArray[randomArrayIndex]);
}
}

public class ColorServer {
    public static void main(String[] args) throws Exception {
        int q_len = 6;// length of the connections to run simultaneously
        int serverPort = 45565;// port to be connected from client
        Socket sock;

        System.out.println("Clark Elliott's Color Server 1.0 starting up, listening at port " + serverPort + "/\n");
//checking on the connection if anyone is calling
        ServerSocket servSock = new ServerSocket(serverPort, q_len);
        System.out.println("ServerSocket awaiting connections..");

        while (true) {
            sock = servSock.accept();//packets of data to be accepted from the client side

            System.out.println("Connection from " + sock);
            new ColorWorker(sock).start();// look for another person to start the data
        }
    }
}