/*
Name: Nihar Muniraju
Date: 01-12-2023
Java Version: 19.0.1
Thanks:

        https://www.comrevo.com/2019/07/Sending-objects-over-sockets-Java-example-How-to-send-serialized-object-over-network-in-Java.html (Code dated 2019-07-09, by Ramesh)
        https://rollbar.com/blog/java-socketexception/#
        Also: Hughes, Shoffner and Winslow for Inet code.

 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ColorClient {
    private static int clientColorCount = 0;// checking the count of the color to the server
    public static void main(String argv[]) {
        ColorClient cc = new ColorClient(argv);
        cc.run(argv);
    }
    public ColorClient(String argv[]) {
        System.out.println("\nThis is the constructor if you want to use it.\n");
    }

    public void run(String argv[]){

        String serverName;
        if (argv.length < 1) serverName = "localhost";//letting know if about the address
        else serverName = argv[0];

        String colorFromClient = "";
        Scanner consoleIn = new Scanner(System.in);
        System.out.println("Enter your name: ");
        System.out.flush();// move it to the server when given data by flushing
        String userName = consoleIn.nextLine();
        System.out.println("Hi " + userName);
        do {
            System.out.println("Enter a color, or quit to end: ");// write a color
            colorFromClient = consoleIn.nextLine();
            if (colorFromClient.indexOf("quit") < 0) {// leave it when not given data
                getColor(userName, colorFromClient, serverName);
            }
        } while (colorFromClient.indexOf("quit") < 0);// if not required then can cancel it
        System.out.println ("Cancelled by user request.");
        System.out.println (userName + ", You sent and received " + clientColorCount + " colors.");
    }

    void getColor(String userName, String colorFromClient, String serverName) {

        try {
            ColorData colorObj = new ColorData();// chekc on ColorServer and compile it to run on client
            colorObj.userName = userName;
            colorObj.colorSent = colorFromClient;
            colorObj.colorCount = clientColorCount;

            Socket socket = new Socket(serverName, 45565);// ports for connections
            System.out.println("\nWe have successfully connected to the ColorServer at port 45,565");

            OutputStream OutputStream = socket.getOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(OutputStream);//constructor

            oos.writeObject(colorObj);//connecting the network to the server file
            System.out.println("We have sent the serialized values to the ColorServer's server spcket");

            InputStream InStream = socket.getInputStream();//input data being sent
            ObjectInputStream ois = new ObjectInputStream(InStream);
            ColorData InObject = (ColorData) ois.readObject();

            clientColorCount = InObject.colorCount;// keeping the data by maintaing the connections between the server and client

            System.out.println("\nFROM THE SERVER:");//get data FROM sERVER
            System.out.println(InObject.messageToClient);
            System.out.println("The color sent back is: " + InObject.colorSentBack);//COLOR BEING SENTBACK
            System.out.println("The color count is: " + InObject.colorCount + "\n");

            System.out.println("Closing the connection to the server.\n");
            socket.close();
        } catch (ConnectException CE){
            System.out.println("\nOh no. The ColorServer refused our connection! Is it running?\n");
            CE.printStackTrace();
        } catch (UnknownHostException UH){//
            System.out.println("\nUnknown Host problem.\n");
            UH.printStackTrace();
        } catch(ClassNotFoundException CNF){//when colorData not being found in classNotFound Exception
            CNF.printStackTrace();
        } catch (IOException IOE){//input output Exception
            IOE.printStackTrace();
        }
    }
}